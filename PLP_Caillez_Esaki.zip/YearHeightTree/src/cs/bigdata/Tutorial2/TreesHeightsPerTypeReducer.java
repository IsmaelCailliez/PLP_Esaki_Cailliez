package cs.bigdata.Tutorial2;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;
import java.util.Iterator;


public class TreesHeightsPerTypeReducer extends Reducer<Text, FloatWritable, Text, FloatWritable> {

	//initialisationd des variables
    private FloatWritable maxTypeHeight = new FloatWritable(); //valeur en sortie : hauteur maximale

    @Override
    public void reduce(final Text key, final Iterable<FloatWritable> values,
            final Context context) throws IOException, InterruptedException {

        
        Iterator<FloatWritable> iterator = values.iterator(); //values contient toutes les hauteurs des arbres d'un meme genre
        
        float maximum=0; //on initialise le max a 0
        
        while (iterator.hasNext()) {
        		maximum=Math.max(maximum,iterator.next().get()); //on compare le max enregistre avec la prochaine hauteur
        }

        maxTypeHeight.set(maximum);
        context.write(key, maxTypeHeight);
    }
}