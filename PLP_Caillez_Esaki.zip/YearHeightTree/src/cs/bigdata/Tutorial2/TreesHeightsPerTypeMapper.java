package cs.bigdata.Tutorial2;


import org.apache.hadoop.io.*;        
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;

// To complete according to your problem
public class TreesHeightsPerTypeMapper extends Mapper<LongWritable, Text, Text, FloatWritable> {

	//initialisation des variables
	private final static FloatWritable hauteur = new FloatWritable(); //valeur en sortie du mapper : hauteur de l'arbre
	private Text genre = new Text(); //cle en sortie du mapper : genre de l'arbre


	// Overriding of the map method
	@Override
	protected void map(LongWritable keyE, Text valE, Context context) throws IOException,InterruptedException
	{


		if (!valE.toString().split(";")[2].equals("GENRE")) { //si on n'est pas sur la 1e ligne

			//definition de la cle
			genre.set(valE.toString().split(";")[2]);

			//definition de la valeur
			try { //si la valeur est bien indiquee...
				hauteur.set(Float.parseFloat(valE.toString().split(";")[6]));
				context.write(genre, hauteur);
			}

			catch (NumberFormatException e) { //sinon on attribue 0 comme hauteur
				FloatWritable zero=new FloatWritable(0);
				context.write(genre, zero);
			}

		}
	}

	public void run(Context context) throws IOException, InterruptedException {
		setup(context);
		while (context.nextKeyValue()) {
			map(context.getCurrentKey(), context.getCurrentValue(), context);
		}
		cleanup(context);
	}
}

