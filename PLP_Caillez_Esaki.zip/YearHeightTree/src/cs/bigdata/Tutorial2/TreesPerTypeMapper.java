package cs.bigdata.Tutorial2;

import org.apache.hadoop.io.*;        
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;

// To complete according to your problem
public class TreesPerTypeMapper extends Mapper<LongWritable, Text, Text, IntWritable> {

	//initialisation des variables
	private final static IntWritable one = new IntWritable(1); //valeur de sortie du mapper : 1
	private Text type = new Text(); //cle de sortie du mapper : le genre de l'arbre

	// Overriding of the map method
	@Override
	protected void map(LongWritable keyE, Text valE, Context context) throws IOException,InterruptedException
	{
		
		if (!valE.toString().split(";")[2].equals("GENRE")) { //si on n'est pas sur la 1e ligne
			//attribution des valaurs aux cle et valeur
			type.set(valE.toString().split(";")[2]);
			context.write(type, one);
		}

		
	}

	public void run(Context context) throws IOException, InterruptedException {
		setup(context);
		while (context.nextKeyValue()) {
			map(context.getCurrentKey(), context.getCurrentValue(), context);
		}
		cleanup(context);
	}
}
