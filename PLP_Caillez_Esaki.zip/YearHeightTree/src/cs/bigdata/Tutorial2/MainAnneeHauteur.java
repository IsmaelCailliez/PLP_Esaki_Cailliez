package cs.bigdata.Tutorial2;

import java.io.*;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.*;

public class MainAnneeHauteur {

	public static void main(String[] args) throws IOException {
		
		String localSrc = "/Users/ayaesaki/Desktop/OMA/PLP/TPs/arbres.txt";
		//Open the file
		Configuration conf = new Configuration();
		FileSystem fs = FileSystem.get(conf);
		InputStream in = new BufferedInputStream(new FileInputStream(localSrc));
		
		
		try{
			
			InputStreamReader isr = new InputStreamReader(in);
			BufferedReader br = new BufferedReader(isr);
			
			// read line by line
			String ligne = br.readLine();
			
			while (ligne !=null){
				
				//on affiche l'annee de plantation et la hauteur de l'arbre represente par la ligne traitee
				System.out.println(Tree.AffichageAnneeHauteur(ligne));
				
				// go to the next line
				ligne = br.readLine();
				
			}
		}
		
		finally{
			//close the file
			in.close();
			fs.close();
		}
 
		
		
	}

}
