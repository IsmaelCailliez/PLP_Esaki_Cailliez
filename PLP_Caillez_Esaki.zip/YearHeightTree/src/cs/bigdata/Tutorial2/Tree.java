package cs.bigdata.Tutorial2;

public class Tree {

	public String geopoint;
	public int arrondissement;
	public String genre;
	public String espece;
	public String famille;
	public static String annee;
	public static String hauteur;
	public String circonference;
	public String adresse;
	public String nom;
	public String variete;
	public int objectif;
	public String nomEv;


	public static String AffichageAnneeHauteur(String ligne) {

		annee=ligne.split(";")[5];
		hauteur=ligne.split(";")[6];

		//initialisation de la chaine de caracteres
		String s="";

		if (annee.equals("ANNEE PLANTATION")) {
			s="ANNEE"+"\t"+hauteur;
		}

		else {
			//ajout de l'annee
			try {
				Integer.parseInt(annee); //on verifie si l'annee est bien indiquee
				s=annee;
			}
			catch (NumberFormatException e) {
				s="N/A";
			}

			s=s+"\t";

			//ajout de la hauteur
			try {
				Float.parseFloat(hauteur);
				s=s+hauteur;
			}
			catch (NumberFormatException e) {
				s=s+"N/A";
			}
		}
		// on retourne le resultat
		return s;
	}


	public static String AffichageGenre(String line) {
		return(line.split(";")[2]);
	}


	public static String AffichageGenreHauteur(String line) {

		//on releve le genre
		String s=line.split(";")[2]+" ";

		//on verifie si la hauteur est bien indiquee
		try {
			Float.parseFloat(line.split(";")[6]);
			s=s+line.split(";")[6];
		}
		catch (NumberFormatException e) {
			s=s+"0";
		}

		//on retourne le resultat
		return s;
	}

}



