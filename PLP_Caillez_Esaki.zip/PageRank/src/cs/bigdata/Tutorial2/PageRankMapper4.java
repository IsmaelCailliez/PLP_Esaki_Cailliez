package cs.bigdata.Tutorial2;
 
import org.apache.hadoop.io.*;        
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;

// To complete according to your problem
public class PageRankMapper4 extends Mapper<LongWritable, Text, DoubleWritable,Text> {
	
	
	private Text keyS= new Text();
	private Text valS = new Text();
	private DoubleWritable pageRankOpp=new DoubleWritable();
	

	// Overriding of the map method
	@Override
	protected void map(LongWritable keyE, Text valE, Context context) throws IOException,InterruptedException
	{
		
		
		keyS.set(valE.toString().split("\t")[0]);
		valS.set(valE.toString().split("\t")[1]);
		
		//pour chaque couple (page, PR de la page)...
		if (!valS.toString().contains("#") && !valS.toString().contains("/") && !valS.toString().contains("{") && !keyS.toString().equals("converged")) {
			pageRankOpp.set(-Double.parseDouble(valS.toString()));
			
			//on renvoie (page, -PR de la page)
			context.write(pageRankOpp,keyS);
		}
		
		
		
	}


	public void run(Context context) throws IOException, InterruptedException {
		setup(context);
		while (context.nextKeyValue()) {
			map(context.getCurrentKey(), context.getCurrentValue(), context);
		}
		cleanup(context);
	}
}
