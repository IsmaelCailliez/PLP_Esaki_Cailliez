package cs.bigdata.Tutorial2;
  
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;


import java.io.IOException;
import java.util.Iterator;


public class PageRankReducer1 extends Reducer<PagePRWritable, Text, Text, Text> {

	Text listeToNodesPR=new Text();

	@Override
	public void reduce(final PagePRWritable key, final Iterable<Text> values,
			final Context context) throws IOException, InterruptedException {

		Iterator<Text> iterator = values.iterator();
		String liste="{"+iterator.next().toString();
	

		while (iterator.hasNext()) {
			liste=liste+";"+iterator.next().toString();
		}
		
		liste=liste+"}";
		listeToNodesPR.set(liste);


		// context.write(key, new IntWritable(sum));
		context.write(key.toText(), listeToNodesPR);
	}
}