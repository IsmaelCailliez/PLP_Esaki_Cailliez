package cs.bigdata.Tutorial2;
 
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;
import java.util.Iterator;


public class PageRankReducer4 extends Reducer<DoubleWritable, Text, Text, Text> {

	private double valS;

	@Override
	public void reduce(final DoubleWritable key, final Iterable<Text> values,
			final Context context) throws IOException, InterruptedException {

		Iterator<Text> itr = values.iterator();

		while (itr.hasNext()) {

			//on reprend la valeur opposee de la cle pour le pageRank
			valS=-key.get(); 

			//on echange cle et valeur
			context.write(itr.next(),new Text(String.valueOf(valS)));
		}
	}


}

