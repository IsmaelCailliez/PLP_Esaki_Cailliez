package cs.bigdata.Tutorial2;
  
import org.apache.hadoop.io.*;        
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;
import java.util.StringTokenizer;

// To complete according to your problem
public class PageRankMapper2 extends Mapper<LongWritable, Text, Text, Text> {
	
	
	private PagePRWritable fromNodePR= new PagePRWritable();
	private Text toNode = new Text();
	
	

	// Overriding of the map method
	@Override
	protected void map(LongWritable keyE, Text valE, Context context) throws IOException,InterruptedException
	{
		
		
		String fromStr = valE.toString().split("\t")[0];
		String listeToNode = valE.toString().split("\t")[1].substring(1, valE.toString().split("\t")[1].length()-1);
		String nbOutLinks;
		Text rapport=new Text();
		
		fromNodePR.set(fromStr.split(";")[0],Double.valueOf(fromStr.split(";")[1]));
	
		
		context.write(fromNodePR.getPage(), fromNodePR.getPageRankText());
		
		StringTokenizer tokToNode = new StringTokenizer(listeToNode ,";");
		nbOutLinks=String.valueOf(tokToNode.countTokens());
	
		
		rapport.set(fromNodePR.getPageRankText().toString()+"/"+nbOutLinks);
		
		while(tokToNode.hasMoreTokens()){
			toNode.set(tokToNode.nextToken());
			context.write(toNode, rapport);
		}
		
		context.write(fromNodePR.getPage() , new Text("{"+listeToNode+"}"));
	}


	public void run(Context context) throws IOException, InterruptedException {
		setup(context);
		while (context.nextKeyValue()) {
			map(context.getCurrentKey(), context.getCurrentValue(), context);
		}
		cleanup(context);
	}
}
