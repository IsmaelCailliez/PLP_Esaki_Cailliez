package cs.bigdata.Tutorial2;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;
import java.util.Iterator;
import java.util.StringTokenizer;


public class PageRankReducer2 extends Reducer<Text, Text, Text, Text> {

	String listeToNode;
	double oldPageRank;

	@Override
	public void reduce(final Text key, final Iterable<Text> values,
			final Context context) throws IOException, InterruptedException {


		Iterator<Text> iterator = values.iterator();

		//sum va servir à calculer le nouveau page rank
		double sum = 0;

		//nombre de liens sortants de la page
		int nbOutLinks;

		//on verifie la convergence
		if (key.toString().equals("converged")) {
			double diff=0;
			
			//on calcule la somme des differences
			while (iterator.hasNext()) {
				double item=Double.parseDouble(iterator.next().toString());
				diff=diff+item;
			}
			
			//si la somme est inferieure a 1e-5 ca converge
			if (diff<0.00001) {
				context.write(key, new Text("1"));
			}
			else {
				context.write(key, new Text("0"));
			}	
		}
		
		
		else {
			while (iterator.hasNext()) {

				Text item = iterator.next();

				//1er cas : item = fromPageRank/fromNbOutLinks
				if (item.toString().contains("/")) {
					double fromPageRank=Double.parseDouble(item.toString().split("/")[0]);
					double fromNbOutLinks=Double.parseDouble(item.toString().split("/")[1]);
					sum = sum + 0.85*fromPageRank/fromNbOutLinks;
				}

				//2e cas : item = {toNode1;toNode2;...}
				else if(item.toString().contains("{")) {
					listeToNode=item.toString().substring(1, item.toString().length()-1);
					context.write(key, item);
				}

				//3e cas : item = #(pageRank_n+1 - pageRank_n)^2
				else  if (item.toString().contains("#")){
				}
				
				//4e cas : item = pageRank
				else {
					oldPageRank=Double.parseDouble(item.toString().substring(1));
					sum = sum + 0.15*oldPageRank;

				}

			}

			String newPageRank=String.valueOf(sum); //nouveau page rank

			//on renvoie le couple (page,PR actualisé de la page)
			context.write(key, new Text(newPageRank)); 

			//on renvoie le couple (page, #(newPageRank - oldPageRank)^2
			double diff=(sum-oldPageRank)*(sum-oldPageRank);
			context.write(key, new Text("#"+String.valueOf(diff)));



			//on fait une boucle sur les ToNodes pour renvoyer les couples (ToNode_i, PR de FromNode / nombre de liens sortant de FromNode)
			StringTokenizer tokToNodes=new StringTokenizer(listeToNode,";");
			nbOutLinks=tokToNodes.countTokens();
			while (tokToNodes.hasMoreTokens()){
				String toNode=tokToNodes.nextToken();
				context.write(new Text(toNode), new Text(newPageRank+"/"+String.valueOf(nbOutLinks) ));
			}
		}
	}


}

