package cs.bigdata.Tutorial2;


import java.io.IOException;


import org.apache.hadoop.conf.Configuration;

import org.apache.hadoop.conf.Configured;

import org.apache.hadoop.fs.FileSystem;

import org.apache.hadoop.fs.Path;

import org.apache.hadoop.mapreduce.Job;

import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;

import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.jobcontrol.ControlledJob;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;


import org.apache.hadoop.util.Tool;

import org.apache.hadoop.util.ToolRunner;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.jobcontrol.JobControl;
import org.apache.hadoop.io.DoubleWritable;


public class PageRank extends Configured implements Tool {

	private Configuration conf;
	private FileSystem fs;


	public int run(String[] args) throws Exception {

		
		//on verifie qu'on a bien les bons arguments
		if (args.length != 2) {
			System.out.println("Usage: [input] [output]");
			System.exit(-1);
		}
		
		conf = getConf();
		fs = FileSystem.newInstance(conf);


		//chemins des input et output
		Path inputFilePath = new Path(args[0]);
		Path outputFilePath = new Path(args[1]);	
		
		final Path pr1=new Path(outputFilePath,"pr1"); //output du 1er mapreduce
		final Path pr2=new Path(outputFilePath,"pr2"); //output du 2e

		//on fait 2 premiers mapreduce pour recuperer les donnees necessaires au calcul du page rank
		final ControlledJob PageRank1=pr1Job(inputFilePath,pr1);
		final ControlledJob PageRank2=pr2Job(pr1,pr2);
		
		final JobControl control=new JobControl("PageRank");
		control.addJob(PageRank1); //ajout du 1er mapreduce
		PageRank2.addDependingJob(PageRank1); //le 2e mapreduce commence seulement apres la fin du 1er
		control.addJob(PageRank2); //ajout du 2e
		
		//on cree une copie du dernier job
		ControlledJob oldJob=PageRank2;
		
		//on initialise lastPath qui va servir à garder une copie du chemin du dernier output
		Path lastPath = null;
		
		//on fait une boucle pour enchainer les mapreduce
		for (int i=3;i<16;i++) {
			
			//chemins des outputs des jobs n-1 et n
			Path oldPath=new Path(outputFilePath,"pr"+String.valueOf(i-1));
			Path newPath=new Path(outputFilePath,"pr"+String.valueOf(i));
			
			//nouveau job
			ControlledJob newJob=pr3Job(oldPath,newPath);
			
			//qui depend du precedent
			newJob.addDependingJob(oldJob);
			
			control.addJob(newJob);
			
			//on cree une copie du job n
			oldJob=newJob;
			
			if (i==15) {
			lastPath=newPath;
			}
			
		}
		
		//on cree un dernier mapreduce qui permet de classer les pages
		Path outputPath=new Path(outputFilePath,"ranks"); //chemin de l'output
		final ControlledJob finalJob=pr4Job(lastPath,outputPath); //nouveau job
		finalJob.addDependingJob(oldJob); //qui depend du dernier
		control.addJob(finalJob); //ajout au controlled job
		
		control.run();
		
		
		return control.allFinished() ? 0 : 1;

	
	}  



/*
	private static int getConvergedValue(String path) throws IOException{
		String localSrc = "/Users/ayaesaki/eclipse-workspace/"+path+"/part-r-00000";
		//Open the file
		Configuration conf = new Configuration();
		FileSystem fs = FileSystem.get(conf);
		InputStream in = new BufferedInputStream(new FileInputStream(localSrc));
		
		
		try{
			
			InputStreamReader isr = new InputStreamReader(in);
			BufferedReader br = new BufferedReader(isr);
			
			// read line by line
			String line = br.readLine();
			
			while(!line.split("\t")[0].equals("converged")) {
				line = br.readLine();
			}
			
			return Integer.parseInt(line.split("\t")[1]);
		}
		finally{
			//close the file
			in.close();
			fs.close();
		}
	}

*/


	public static void main(String[] args) throws Exception {

		PageRank exempleDriver = new PageRank();

		int res = ToolRunner.run(exempleDriver, args);

		System.exit(res);
		

	}


	private ControlledJob pr1Job(Path input,Path output) throws IOException{
		final Job job=new Job(conf,"PageRank1");

		//on precise les mapper et reducer
		job.setJarByClass(PageRankMapper1.class);
        job.setMapperClass(PageRankMapper1.class);
        job.setReducerClass(PageRankReducer1.class);

        //on precise les types des output 
        job.setMapOutputKeyClass(PagePRWritable.class);
        job.setMapOutputValueClass(Text.class);
        job.setOutputKeyClass(TextInputFormat.class);
        job.setOutputValueClass(TextOutputFormat.class);

        //on precise les formats de input et output
		FileInputFormat.addInputPath(job, input);
		job.setInputFormatClass(TextInputFormat.class);
		FileOutputFormat.setOutputPath(job, output);
		job.setOutputFormatClass(TextOutputFormat.class);

		
		if (fs.exists(output)) {
			fs.delete(output,true);
		}

		return new ControlledJob(job, null);
	}

	private ControlledJob pr2Job(Path input,Path output) throws IOException {
		final Job job = new Job(conf,"PageRank2");


		job.setJarByClass(PageRankMapper2.class);
		job.setMapperClass(PageRankMapper2.class);
		job.setReducerClass(PageRankReducer2.class);

		job.setMapOutputKeyClass(Text.class);
	    job.setMapOutputValueClass(Text.class);
	    job.setOutputKeyClass(TextInputFormat.class);
	    job.setOutputValueClass(TextOutputFormat.class);


		FileInputFormat.addInputPath(job, input);
		job.setInputFormatClass(TextInputFormat.class);
		FileOutputFormat.setOutputPath(job, output);
		job.setOutputFormatClass(TextOutputFormat.class);

		if (fs.exists(output)) {
			fs.delete(output,true);
		}

		return new ControlledJob(job, null);
	}
	
	private ControlledJob pr3Job(Path input,Path output) throws IOException {
		final Job job = new Job(conf,"PageRank3");


		job.setJarByClass(PageRankMapper3.class);
		job.setMapperClass(PageRankMapper3.class);
		job.setReducerClass(PageRankReducer2.class);

		job.setMapOutputKeyClass(Text.class);
	    job.setMapOutputValueClass(Text.class);
	    job.setOutputKeyClass(TextInputFormat.class);
	    job.setOutputValueClass(TextOutputFormat.class);


		FileInputFormat.addInputPath(job, input);
		job.setInputFormatClass(TextInputFormat.class);
		FileOutputFormat.setOutputPath(job, output);
		job.setOutputFormatClass(TextOutputFormat.class);

		if (fs.exists(output)) {
			fs.delete(output,true);
		}

		return new ControlledJob(job, null);
	}
	
	private ControlledJob pr4Job(Path input,Path output) throws IOException {
		final Job job = new Job(conf,"PageRank3");


		job.setJarByClass(PageRankMapper4.class);
		job.setMapperClass(PageRankMapper4.class);
		job.setReducerClass(PageRankReducer4.class);

		job.setMapOutputKeyClass(DoubleWritable.class);
	    job.setMapOutputValueClass(Text.class);
	    job.setOutputKeyClass(TextInputFormat.class);
	    job.setOutputValueClass(TextOutputFormat.class);


		FileInputFormat.addInputPath(job, input);
		job.setInputFormatClass(TextInputFormat.class);
		FileOutputFormat.setOutputPath(job, output);
		job.setOutputFormatClass(TextOutputFormat.class);

		if (fs.exists(output)) {
			fs.delete(output,true);
		}

		return new ControlledJob(job, null);
	}


}