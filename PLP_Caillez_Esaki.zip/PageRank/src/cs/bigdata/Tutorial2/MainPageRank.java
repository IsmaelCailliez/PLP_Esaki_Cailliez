package cs.bigdata.Tutorial2;



import java.io.*;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.*;



public class MainPageRank {

	public static void main(String[] args) throws IOException {

		String localSrc = "/Users/ayaesaki/eclipse-workspace/PageRank/output/ranks/part-r-00000";
		//Open the file
		Configuration conf = new Configuration();
		FileSystem fs = FileSystem.get(conf);
		InputStream in = new BufferedInputStream(new FileInputStream(localSrc));


		try{

			InputStreamReader isr = new InputStreamReader(in);
			BufferedReader br = new BufferedReader(isr);

			// read line by line
			String line = br.readLine();

			int lineNb=0; //iterateur pour compter le nombre de lignes

			// 1e ligne affichant les noms des colonnes
			System.out.println("Rank"+"\t"+"Page"+"\t"+"PageRank");

			//on n'affiche que les 20 premieres pages
			while (line !=null && lineNb<10){
				lineNb ++;
				
				System.out.print(lineNb+"\t"); //rang
				System.out.print(line.split("\t")[0]+"\t"); //page
				System.out.println(line.split("\t")[1]); //page
				
				// go to the next line
				line = br.readLine();
			}
		}

		finally{
			//close the file
			in.close();
			fs.close();
		}



	}

}
