package cs.bigdata.Tutorial2;

import org.apache.hadoop.io.*;        
import org.apache.hadoop.mapreduce.Mapper;


import java.io.IOException;

// To complete according to your problem
public class PageRankMapper1 extends Mapper<LongWritable, Text, PagePRWritable, Text> {

	private final static PagePRWritable fromNodePR = new PagePRWritable();
	private final static Text toNode = new Text();
	double pageRankInit;

	
	// Overriding of the map method

	@Override
	protected void map(LongWritable keyE, Text valE, Context context) throws IOException,InterruptedException
	{
		
		double nbNodes;
	
		//les premieres lignes ne contiennent pas de FromNodeID, ToNodeID
		if (valE.toString().substring(0, 1).equals("#")) {
			
			//on recupere le nombre de noeuds pour calculer le page rank initial 1/nb de noeuds
			if (valE.toString().substring(2, 7).equals("Nodes")){
				nbNodes=Double.parseDouble(valE.toString().substring(9, 14));
				pageRankInit=1/nbNodes;
			}	
		}
		
		//on recupere les liens FromNodeID, ToNodeID
		else {
			String fromNode = valE.toString().split("\t")[0];
			fromNodePR.set(fromNode, pageRankInit);
			toNode.set(valE.toString().split("\t")[1]);;

			context.write(fromNodePR,toNode);
		}
	}


	public void run(Context context) throws IOException, InterruptedException {
		setup(context);

		while (context.nextKeyValue()) {
			map(context.getCurrentKey(), context.getCurrentValue(), context);
		}

		cleanup(context);
	}
}
