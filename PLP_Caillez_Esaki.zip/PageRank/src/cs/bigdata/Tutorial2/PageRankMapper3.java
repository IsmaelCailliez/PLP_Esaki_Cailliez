package cs.bigdata.Tutorial2;

import org.apache.hadoop.io.*;        
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;

// To complete according to your problem
public class PageRankMapper3 extends Mapper<LongWritable, Text, Text, Text> {
	
	
	private Text keyS= new Text();
	private Text valS = new Text();
	
	

	// Overriding of the map method
	@Override
	protected void map(LongWritable keyE, Text valE, Context context) throws IOException,InterruptedException
	{
		
		
		keyS.set(valE.toString().split("\t")[0]);
		valS.set(valE.toString().split("\t")[1]);
		
		//pour chaque couple (page, #difference entre les 2 valeurs)...
		if (valS.toString().substring(0, 1).equals("#")) {
			//on renvoie (converged,difference)
			context.write(new Text("converged"), new Text(valS.toString().substring(1)));
		}
		
		//sinon on renvoie simplement (cle,valeur)
		else if (!keyS.toString().equals("converged")) { //on ignore la ligne (converged, 0)
		context.write(keyS , valS);
		}
	}


	public void run(Context context) throws IOException, InterruptedException {
		setup(context);
		while (context.nextKeyValue()) {
			map(context.getCurrentKey(), context.getCurrentValue(), context);
		}
		cleanup(context);
	}
}
