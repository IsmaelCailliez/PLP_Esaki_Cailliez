package cs.bigdata.Tutorial2;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;


public class PagePRWritable implements WritableComparable <PagePRWritable> {
	
	private Text page;
	private DoubleWritable pageRank;
	
	
	public PagePRWritable() {
		page=new Text();
		pageRank=new DoubleWritable();
		
	}

	
	public PagePRWritable(String page,double pageRank) {
		this.page=new Text(page);
		this.pageRank=new DoubleWritable(pageRank);
		
	}
	

	
	@Override
	public void readFields(DataInput input) throws IOException {
		page.readFields(input);
		pageRank.readFields(input);
		
	}
	
	
	@Override
	public void write(DataOutput output) throws IOException {
		page.write(output);
		pageRank.write(output);
		
	}
	
	@Override
	public int compareTo(PagePRWritable o) {
		return page.compareTo(o.page);
		
	}
	
	
	public void set(String page,double pagerank) {
		this.page=new Text(page);
		this.pageRank=new DoubleWritable(pagerank);
	}
	
	
	public void set(Text page,double pagerank) {
		this.page=page;
		this.pageRank=new DoubleWritable(pagerank);
	}
	
	

	
	public DoubleWritable getPageRank() {
		return pageRank;
	}
	
	public Text getPageRankText() {
		return new Text(pageRank.toString());
	}
	

	
	public Text getPage() {
		return page;
	}
	
	
	public Text toText() {
		return new Text(page.toString()+";"+pageRank.toString());
	}
	
	public String toString() {
		return page.toString()+"_"+pageRank.toString();
	}
	
}

