package cs.bigdata.Tutorial2;

public class Station {

	public static String usaf;
	public static String wban;
	public static String stationName;
	public static String ctryFips;
	public static String state;
	public static String latiture;
	public static String longitude;
	public static String elevation;
	public static String beginPeriod;
	public static String endPeriod;
	
 
	public static String AffichageUsaf(String line) {
		
		usaf=line.substring(0,6);
		
		String s="";
		try {
			Integer.parseInt(usaf); //on verifie si le usaf code est bien indique
			s=usaf;
		}
		catch (NumberFormatException e) {
			s="N/A ";
		}
		return s;

	}
	
	public static String AffichageName(String line) {
	
		stationName=line.substring(13,42);
		if (stationName.replaceAll("\\s", "").equals("") ){  //on verifie si le nom est bien indique
			return "N/A"+stationName.substring(4);
		}
		else {
			return stationName;
		}

	}
	
	public static String AffichageFips(String line) {
		
		ctryFips=line.substring(43,45);
		if (ctryFips.replaceAll("\\s", "").equals("") ){ //on verifie si le fips est bien indique
			return "N/A";
		}
		else {
			return ctryFips;
		}

	}
	
	public static String AffichageElev(String line) {
		elevation=line.substring(74,81);
		
		if (elevation.replaceAll("\\s", "").equals("") ){ //on verifie si l'elevation est bien indiquee
			return "N/A";
		}
		else {
			return elevation;
		}

	}
}