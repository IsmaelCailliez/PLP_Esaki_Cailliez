package cs.bigdata.Tutorial2;



import java.io.*;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.*;



public class MainStations {

	public static void main(String[] args) throws IOException {

		String localSrc = "/Users/ayaesaki/Desktop/OMA/PLP/TPs/isd-history.txt";
		//Open the file
		Configuration conf = new Configuration();
		FileSystem fs = FileSystem.get(conf);
		InputStream in = new BufferedInputStream(new FileInputStream(localSrc));


		try{

			InputStreamReader isr = new InputStreamReader(in);
			BufferedReader br = new BufferedReader(isr);

			// read line by line
			String line = br.readLine();


			//on saute les 22 premieres lignes
			for (int i=1;i<23;i+=1) {
				line = br.readLine();
			}
			
			

			//while (line !=null){
			int compteur=0;
			while (line !=null && compteur<20){
				compteur ++;
				
				//on affiche les differents arguments de la station
				System.out.print(Station.AffichageUsaf(line)+"\t");
				System.out.print(Station.AffichageName(line)+"\t");
				System.out.print(Station.AffichageFips(line)+"\t");
				System.out.println(Station.AffichageElev(line));

				// go to the next line
				line = br.readLine();
				
			}

		}

		finally{
			//close the file
			in.close();
			fs.close();
		}



	}

}
