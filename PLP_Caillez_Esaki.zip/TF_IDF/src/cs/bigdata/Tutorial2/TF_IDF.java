package cs.bigdata.Tutorial2;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;

import org.apache.hadoop.conf.Configured;

import org.apache.hadoop.fs.FileSystem;

import org.apache.hadoop.fs.Path;

import org.apache.hadoop.mapreduce.Job;

import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;

import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.jobcontrol.ControlledJob;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;


import org.apache.hadoop.util.Tool;

import org.apache.hadoop.util.ToolRunner;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.jobcontrol.JobControl;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;


public class TF_IDF extends Configured implements Tool {

	private Configuration conf;
	private FileSystem fs;


	public int run(String[] args) throws Exception {

		if (args.length != 2) {

			System.out.println("Usage: [input] [output]");

			System.exit(-1);

		}

		Path inputFilePath = new Path(args[0]);
		Path outputFilePath = new Path(args[1]);

		conf = getConf();
		fs = FileSystem.newInstance(conf);

		final Path output1=new Path(outputFilePath,"output1");
		final Path output2=new Path(outputFilePath,"output2");
		final Path output3=new Path(outputFilePath,"output3");
		final Path output4=new Path(outputFilePath,"output4");

		final ControlledJob WordCount1=wc1Job(inputFilePath,output1);
		final ControlledJob WordCount2=wc2Job(output1,output2);
		final ControlledJob WordCount3=wc3Job(output2,output3);
		final ControlledJob WordCount4=wc4Job(output3,output4);

		final JobControl control=new JobControl("TF_IDF");
		control.addJob(WordCount1);
		WordCount2.addDependingJob(WordCount1);
		control.addJob(WordCount2);
		WordCount3.addDependingJob(WordCount1);
		WordCount3.addDependingJob(WordCount2);
		control.addJob(WordCount3);
		WordCount4.addDependingJob(WordCount1);
		WordCount4.addDependingJob(WordCount2);
		WordCount4.addDependingJob(WordCount3);
		control.addJob(WordCount4);

		control.run();
		return control.allFinished() ? 0 : 1;

	}  




	public static void main(String[] args) throws Exception {

		TF_IDF exempleDriver = new TF_IDF();

		int res = ToolRunner.run(exempleDriver, args);

		System.exit(res);
		

	}


	private ControlledJob wc1Job(Path input,Path output) throws IOException{
		final Job job=new Job(conf,"WordCount");

		job.setNumReduceTasks(4);

		job.setJarByClass(WordCountMapper.class);
		job.setMapperClass(WordCountMapper.class);
		job.setReducerClass(WordCountReducer.class);

		job.setMapOutputKeyClass(WordDocWritable.class);
		job.setMapOutputValueClass(IntWritable.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);

		FileInputFormat.addInputPath(job, input);
		job.setInputFormatClass(TextInputFormat.class);
		FileOutputFormat.setOutputPath(job, output);
		job.setOutputFormatClass(TextOutputFormat.class);

		if (fs.exists(output)) {
			fs.delete(output,true);
		}

		return new ControlledJob(job, null);
	}

	private ControlledJob wc2Job(Path input,Path output) throws IOException {
		final Job job = new Job(conf,"WordCountPerDoc");

		job.setNumReduceTasks(4);

		job.setJarByClass(WordCountPerDocMapper.class);
		job.setMapperClass(WordCountPerDocMapper.class);
		job.setReducerClass(WordCountPerDocReducer.class);

		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(WordWcountWritable.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);

		FileInputFormat.addInputPath(job, input);
		job.setInputFormatClass(TextInputFormat.class);
		FileOutputFormat.setOutputPath(job, output);
		job.setOutputFormatClass(TextOutputFormat.class);

		if (fs.exists(output)) {
			fs.delete(output,true);
		}

		return new ControlledJob(job, null);
	}

	private ControlledJob wc3Job(Path input,Path output) throws IOException {
		final Job job = new Job(conf,"DocCount");

		job.setNumReduceTasks(4);

		job.setJarByClass(DocCountMapper.class);
		job.setMapperClass(DocCountMapper.class);
		job.setReducerClass(DocCountReducer.class);

		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(DocWcWpdWritable.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);

		FileInputFormat.addInputPath(job, input);
		job.setInputFormatClass(TextInputFormat.class);
		FileOutputFormat.setOutputPath(job, output);
		job.setOutputFormatClass(TextOutputFormat.class);

		if (fs.exists(output)) {
			fs.delete(output,true);
		}

		return new ControlledJob(job, null);
	}

	private ControlledJob wc4Job(Path input,Path output) throws IOException {
		final Job job = new Job(conf,"WordRank");

		job.setNumReduceTasks(4);

		job.setJarByClass(WordRankMapper.class);
		job.setMapperClass(WordRankMapper.class);
		job.setReducerClass(WordRankReducer.class);

		job.setMapOutputKeyClass(DoubleWritable.class);
		job.setMapOutputValueClass(Text.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);

		FileInputFormat.addInputPath(job, input);
		job.setInputFormatClass(TextInputFormat.class);
		FileOutputFormat.setOutputPath(job, output);
		job.setOutputFormatClass(TextOutputFormat.class);
		

		if (fs.exists(output)) {
			fs.delete(output,true);
		}

		return new ControlledJob(job, null);
	}



}