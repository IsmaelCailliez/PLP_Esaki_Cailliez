package cs.bigdata.Tutorial2;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;
import java.util.Iterator;


public class DocCountReducer extends Reducer<Text, DocWcWpdWritable, Text, Text> {

	//initialisation des variables
	private WcWpdDpwWritable valS = new WcWpdDpwWritable(); //[wordCount,wordsPerDoc,docsPerWord] qui va permettre de calculer le tf-idf
	private WordDocWritable keyS=new WordDocWritable(); //cle de sortie : [word,docID]
	private double tf_idf; //valeur de sortie
	private double nbDocs=2; //nombre total de documents
	private Text output=new Text(); //valeur de sortie sous format texte

	@Override
	public void reduce(final Text key, final Iterable<DocWcWpdWritable> values,
			final Context context) throws IOException, InterruptedException {

		IntWritable docsPerWord=new IntWritable(); //nombre de documents ou apparait le mot
		int sum = 0; // va permettre de calculer docsPerWord
		Iterator<DocWcWpdWritable> itr = values.iterator(); //values contient [(doc1,wordCount1 du mot,wordsPerDoc1),(doc2,wordCount2 du mot,wordsPerDoc2)...]

		//on parcourt tous les documents ou apparait le mot
		while (itr.hasNext()) {	
			DocWcWpdWritable item=itr.next();
			sum ++;
			keyS.set(key,item.getDocID()); //calcul de la cle de sortie
			
			//calcul de docsPerWord
			if (itr.hasNext() && sum==1 || sum==2) { //si (on est au 1e doc et qu'il y en a un 2e) ou (on est au 2e doc)
				docsPerWord.set(2); //il y a 2 documents
			}else {
				docsPerWord.set(1); //sinon, il n'y en a qu'1
			}
			
			//calcul du tf-idf
			valS.set(item.getWordCount(),item.getWordsPerDoc(),docsPerWord); //on stocke toutes les données dont on a besoin pour le calcul
			tf_idf=valS.getWordCount()/valS.getWordsPerDoc()*Math.log10(nbDocs/valS.getDocsPerWord());//calcul du tf-idf
			output.set(String.valueOf(tf_idf));
			
			context.write(keyS.toText(), output);
		}




	}
}