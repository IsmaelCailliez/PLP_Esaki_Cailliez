package cs.bigdata.Tutorial2;
 
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;


public class WordRankMapper extends Mapper<LongWritable, Text, DoubleWritable, Text> {
	
	//initialisation des cle et valeur
	private final DoubleWritable tf_idf=new DoubleWritable(); //cle de sortie du mapper --> tf-idf du (mot,doc)
	private final Text wordDocID=new Text(); //valeur en sortie du mapper : [mot,doc]

	// Overriding of the map method
	@Override
	protected void map(LongWritable keyE, Text valE, Context context) throws IOException,InterruptedException
	{
		
		//attribution des valeurs aux cle et valeur
		tf_idf.set(-Double.valueOf(valE.toString().split("\t")[1])); //on prend la valeur opposee du tf-idf pour les classer dans l'ordre descendant
		wordDocID.set(valE.toString().split("\t")[0]);

		context.write(tf_idf, wordDocID);
	}

	public void run(Context context) throws IOException, InterruptedException {
		setup(context);
		while (context.nextKeyValue()) {
			map(context.getCurrentKey(), context.getCurrentValue(), context);
		}
		cleanup(context);
	}

}