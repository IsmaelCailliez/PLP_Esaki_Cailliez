package cs.bigdata.Tutorial2;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;


public class  WordWcountWritable implements WritableComparable <WordWcountWritable>{

	//declaration des attributs
	private Text word; //mot
	private IntWritable wordCount; //nombre d'occurrences du mot dans un document
	
	
	//1er constructeur sans arguments
	public WordWcountWritable() {
		this.word=new Text();
		this.wordCount=new IntWritable();
	}

	//2d constructeur avec arguments
	public WordWcountWritable(Text word,int wordCount) {
		this.word=word;
		this.wordCount=new IntWritable(wordCount);
	}



	@Override
	public void readFields(DataInput input) throws IOException {
		word.readFields(input);
		wordCount.readFields(input);
		
	}



	@Override
	public void write(DataOutput output) throws IOException {
		word.write(output);
		wordCount.write(output);
	}



	@Override
	public int compareTo(WordWcountWritable o) {
		// TODO Auto-generated method stub
		return word.compareTo(o.word);
		
	}
	
	
	//setters
	public void set(String word,int wordCount) {
		// TODO Auto-generated method stub
		this.word=new Text(word);
		this.wordCount=new IntWritable(wordCount);
	}

	public void set(Text word, int wordCount) {
		// TODO Auto-generated method stub
		this.word=word;
		this.wordCount=new IntWritable(wordCount);
	}
	
	
	//getters
	public IntWritable getWordCount() {
		// TODO Auto-generated method stub
		return this.wordCount;
	}
	
	public Text getWord() {
		// TODO Auto-generated method stub
		Text w=new Text();
		w.set(word);
		return w;
	}


	
}
	