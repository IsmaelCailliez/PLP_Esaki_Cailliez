package cs.bigdata.Tutorial2;

import org.apache.hadoop.io.*;        
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;


public class WordCountPerDocMapper extends Mapper<LongWritable, Text, Text, WordWcountWritable> {

	//initialisation des variables
	private final static WordWcountWritable wordWcount = new WordWcountWritable(); //valeur en sortie du mapper : [mot,wordCount dans un document]
	private Text docID = new Text(); //cle en sortie du mapper : nom du document
	
	
	// Overriding of the map method
	@Override
	protected void map(LongWritable keyE, Text valE, Context context) throws IOException,InterruptedException
	{
		
		//recuperer les donnes en sortie du reducer 1
		String wordDocID = valE.toString().split("\t")[0]; //1e partie de la ligne --> (mot;nom du doc)
		String wordCount=valE.toString().split("\t")[1]; //2e partie de la ligne --> nombre d'occurences du mot dans ce doc

		//attribution des valeurs aux cle et valeur de sortie
		docID.set(wordDocID.split(";")[1]);
		wordWcount.set(wordDocID.split(";")[0], Integer.parseInt(wordCount));
		context.write(docID, wordWcount);

	}

	public void run(Context context) throws IOException, InterruptedException {
		setup(context);
		while (context.nextKeyValue()) {
			map(context.getCurrentKey(), context.getCurrentValue(), context);
		}
		cleanup(context);
	}

}