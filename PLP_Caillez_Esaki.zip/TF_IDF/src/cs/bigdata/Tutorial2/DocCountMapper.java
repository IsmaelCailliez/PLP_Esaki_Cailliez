package cs.bigdata.Tutorial2;
 
import org.apache.hadoop.io.*;        
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;


public class DocCountMapper extends Mapper<LongWritable,Text, Text, DocWcWpdWritable> {
	
	//initialisation des variables
	private final static DocWcWpdWritable valI = new DocWcWpdWritable(); //valeur en sortie du mapper : [docID, wordCount dans ce doc, wordsPerDoc]
	private Text word = new Text(); //cle en sortie du mapper : mot
// Overriding of the map method
@Override
protected void map(LongWritable keyE, Text valE, Context context) throws IOException,InterruptedException
    {
        
		//on recupere les donnees en sortie du reducer2
		String wordDocID = valE.toString().split("\t")[0]; //1e partie de la ligne --> (mot;docID)
		String wcWpd=valE.toString().split("\t")[1]; //2e partie de la ligne --> (wordCount;wordsPerDoc)
		
		//definition des cle et valeur de sortie
		word.set(wordDocID.split(";")[0]);
		valI.set(wordDocID.split(";")[1], Integer.parseInt(wcWpd.split(";")[0]),Integer.parseInt(wcWpd.split(";")[1]));
		context.write(word, valI);
		
    }

public void run(Context context) throws IOException, InterruptedException {
    setup(context);
    while (context.nextKeyValue()) {
        map(context.getCurrentKey(), context.getCurrentValue(), context);
    }
    cleanup(context);
}

}