package cs.bigdata.Tutorial2;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;


public class  WcountWperDWritable implements WritableComparable <WcountWperDWritable>{

	//attributs
	private IntWritable wordsPerDoc;  //nombre total de mots dans un document
	private IntWritable wordCount;  //nombre d'occurrences d'un mot dans un document
	
	
	//constructeur par defaut
	public WcountWperDWritable() {
		this.wordsPerDoc=new IntWritable();
		this.wordCount=new IntWritable();
	}

	
	//constructeur avec arguments
	public WcountWperDWritable(IntWritable wordCount,IntWritable wordsPerDoc) {
		this.wordsPerDoc=wordsPerDoc;
		this.wordCount=wordCount;
	}


	@Override
	public void readFields(DataInput input) throws IOException {
		(wordsPerDoc).readFields(input);
		(wordCount).readFields(input);
	}



	@Override
	public void write(DataOutput output) throws IOException {
		wordsPerDoc.write(output);
		wordCount.write(output);
	}


	@Override
	public int compareTo(WcountWperDWritable o) {
		// TODO Auto-generated method stub
		if(wordCount.compareTo(o.wordCount)==0) {
			return wordsPerDoc.compareTo(o.wordsPerDoc);
		}else {
			return wordCount.compareTo(o.wordCount);
		}
	}
	
	
	//setters
	public void set(IntWritable wordCount,IntWritable wordsPerDoc) {
		// TODO Auto-generated method stub
		this.wordCount=wordCount;
		this.wordsPerDoc=wordsPerDoc;
	}

	public void set(int wordCount, int wordsPerDoc) {
		// TODO Auto-generated method stub
		this.wordCount=new IntWritable(wordCount);
		this.wordsPerDoc=new IntWritable(wordsPerDoc);
	}
	
	public void set(IntWritable wordCount, int wordsPerDoc) {
		// TODO Auto-generated method stub
		this.wordCount=wordCount;
		this.wordsPerDoc=new IntWritable(wordsPerDoc);
	}

	
	//getters
	public IntWritable getWordCount() {
		// TODO Auto-generated method stub
		return this.wordCount;
	}
	
	public IntWritable getWordsPerDoc() {
		// TODO Auto-generated method stub
		return this.wordsPerDoc;
	}
	
	
	//methode pour convertir en texte
	public Text toText() {
		return new Text(wordCount.toString()+";"+wordsPerDoc.toString());
	}






	
}
	