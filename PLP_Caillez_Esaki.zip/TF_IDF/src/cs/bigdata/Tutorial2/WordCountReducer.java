package cs.bigdata.Tutorial2;
 
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;
import java.util.Iterator;
import org.apache.hadoop.io.IntWritable;


public class WordCountReducer extends Reducer<WordDocWritable, IntWritable, Text, IntWritable> {

	//initialisation des valeurs
    private IntWritable totalWordCount = new IntWritable(); //valeur de sortie : wordCount du mot dans un document

    @Override
    public void reduce(final WordDocWritable key, final Iterable<IntWritable> values,
            final Context context) throws IOException, InterruptedException {

        int sum = 0;
        Iterator<IntWritable> iterator = values.iterator(); //values contient [1,1,...]

        while (iterator.hasNext()) {
            sum += iterator.next().get();
        }

        totalWordCount.set(sum);
        context.write(key.toText(), totalWordCount);
    }
}