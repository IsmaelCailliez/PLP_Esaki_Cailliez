package cs.bigdata.Tutorial2;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;


public class  WcWpdDpwWritable implements WritableComparable <WcWpdDpwWritable>{
	
	//attributs
	private IntWritable wordCount; //nombre d'occurrences d'un mot dans un document
	private IntWritable wordsPerDoc;  //nombre total de mots dans un document
	private IntWritable docsPerWord;  //nombre de documents ou le mot apparait
	
	//1er constructeur par defaut
	public WcWpdDpwWritable() {
		this.wordCount=new IntWritable();
		this.wordsPerDoc=new IntWritable();
		this.docsPerWord=new IntWritable();
	}

	//2d constructeur avec arguments
	public WcWpdDpwWritable(IntWritable wordCount,IntWritable wordsPerDoc,IntWritable docsPerWord) {
		this.wordsPerDoc=wordsPerDoc;
		this.wordCount=wordCount;
		this.docsPerWord=docsPerWord;
	}



	@Override
	public void readFields(DataInput input) throws IOException {
		wordsPerDoc.readFields(input);
		wordCount.readFields(input);
		docsPerWord.readFields(input);
	}


	@Override
	public void write(DataOutput output) throws IOException {
		wordsPerDoc.write(output);
		wordCount.write(output);
		docsPerWord.write(output);
	}


	@Override
	public int compareTo(WcWpdDpwWritable o) {
		// TODO Auto-generated method stub
		if(wordCount.compareTo(o.wordCount)==0) {
			if(wordsPerDoc.compareTo(o.wordsPerDoc)==0) {
				return docsPerWord.compareTo(docsPerWord);
			}else {
				return wordsPerDoc.compareTo(o.wordsPerDoc);
			}
			
		}else {
			return wordCount.compareTo(o.wordCount);
		}
	}
	
	
	//setters
	public void set(IntWritable wordCount,IntWritable wordsPerDoc,IntWritable docsPerWord) {
		// TODO Auto-generated method stub
		this.wordCount=wordCount;
		this.wordsPerDoc=wordsPerDoc;
		this.docsPerWord=docsPerWord;
	}

	public void set(int wordCount, int wordsPerDoc,int docsPerWord) {
		// TODO Auto-generated method stub
		this.wordCount=new IntWritable(wordCount);
		this.wordsPerDoc=new IntWritable(wordsPerDoc);
		this.docsPerWord=new IntWritable(docsPerWord);
	}

	
	//getters
	public double getWordCount() {
		// TODO Auto-generated method stub
		return (double)this.wordCount.get();
	}
	
	public double getWordsPerDoc() {
		// TODO Auto-generated method stub
		return (double)this.wordsPerDoc.get();
	}
	
	public double getDocsPerWord() {
		// TODO Auto-generated method stub
		return (double)this.docsPerWord.get();
	}

	
	//methode pour convertir en text
	public Text toText() {
		return new Text(wordCount.toString()+";"+wordsPerDoc.toString()+";"+docsPerWord);
	}

	
}
	