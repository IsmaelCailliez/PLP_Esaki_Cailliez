package cs.bigdata.Tutorial2;
 
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;


public class WordCountPerDocReducer extends Reducer<Text, WordWcountWritable, Text, Text> {

	//initialisation des valeurs
	private WcountWperDWritable valS = new WcountWperDWritable(); // valeur de sortie : [wordCount par mot par doc;wordsPerDoc]
	private WordDocWritable keyS=new WordDocWritable(); //cle de sortie [mot;doc]

	@Override
	public void reduce(final Text key, final Iterable<WordWcountWritable> values,
			final Context context) throws IOException, InterruptedException {

		
		int sum = 0; //sum sert a compter le nombre total de mots dans un doc
		Text word=new Text();
		Iterator<WordWcountWritable> itr = values.iterator(); //values contient [(word1,wordCount1);(word2,wordCount2)...] pour un doc
		Collection<WordWcountWritable> valuesCopy=new ArrayList<>(); //on va creer une copie de values

		//1e boucle permettant de calculer le nombre total de mots par doc
		while (itr.hasNext()) {
			WordWcountWritable item=itr.next();
			sum =sum+item.getWordCount().get(); //on incremente sum avec le wordCount de chaque mot
			WordWcountWritable copy =new WordWcountWritable(item.getWord(),item.getWordCount().get()); //on cree une copie du couple (word,wordCount)
			valuesCopy.add(copy); //on l'ajoute a la nouvelle collection
		}
		
		//on cree un 2e iterateur pour calculer les cles et valeurs
		Iterator<WordWcountWritable> itrCopy = valuesCopy.iterator();
		while (itrCopy.hasNext()) {
			WordWcountWritable item2=itrCopy.next();
			word.set(item2.getWord());
			keyS.set(word, key);
			valS.set(item2.getWordCount(),sum);
			context.write(keyS.toText(), valS.toText()); //on convertit les cle et valeur en textes
		}




	}
}