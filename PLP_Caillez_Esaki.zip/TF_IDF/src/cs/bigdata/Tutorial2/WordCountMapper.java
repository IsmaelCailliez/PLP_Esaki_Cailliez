package cs.bigdata.Tutorial2;

 
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;

import java.io.IOException;
import java.util.StringTokenizer;


public class WordCountMapper extends Mapper<LongWritable, Text, WordDocWritable, IntWritable> {

	// initialisation des variables
	private final static IntWritable one = new IntWritable(1); //valeur en sortie du mapper
	private WordDocWritable wordDoc=new WordDocWritable(); //cle en sortie du mapper
	
	@Override
	protected void map(LongWritable keyE, Text valE, Context context) throws IOException,InterruptedException
	{
		
		//nom du document
		String docID=((FileSplit) context.getInputSplit()).getPath().toString().substring(52); 

		//ligne du texte
		String line = valE.toString().replaceAll("\\p{P}", "").toLowerCase();

		
		//on parcourt la ligne
		StringTokenizer tokenizer = new StringTokenizer(line);
		while(tokenizer.hasMoreTokens())
		{
			wordDoc.set(tokenizer.nextToken(),docID); //on cree le couple (mot,document)
			context.write(wordDoc, one); //on attribue au couple la valeur 1
		}
	}

	public void run(Context context) throws IOException, InterruptedException {
		setup(context);
		while (context.nextKeyValue()) {
			map(context.getCurrentKey(), context.getCurrentValue(), context);
		}
		cleanup(context);
	}

}