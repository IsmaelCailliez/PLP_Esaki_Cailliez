package cs.bigdata.Tutorial2;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.Text;


public class  WordDocWritable implements WritableComparable <WordDocWritable>{

	//attributs
	private Text word; //mot
	private Text docID; //nom du document
	
	
	//1er constructeur sans arguments
	public WordDocWritable() {
		this.word=new Text();
		this.docID=new Text();
	}

	//2d constructeur avec arguments
	public WordDocWritable(Text word, Text docID) {
		this.word=word;
		this.docID=docID;

	}



	@Override
	public void readFields(DataInput input) throws IOException {
		(word).readFields(input);
		(docID).readFields(input);
		
	}



	@Override
	public void write(DataOutput output) throws IOException {
		word.write(output);
		docID.write(output);
	}



	@Override
	public int compareTo(WordDocWritable o) {
		// TODO Auto-generated method stub
		if(word.compareTo(o.word)==0) {
			return docID.compareTo(o.docID);
		}else {
			return word.compareTo(o.word);
		}
		
	}
	
	
	//setter
	public void set(Text word, Text docID) {
		// TODO Auto-generated method stub
		this.word=word;
		this.docID=docID;
	}
	
	public void set(String word, String docID) {
		// TODO Auto-generated method stub
		this.word=new Text(word);
		this.docID=new Text(docID);
	}
	
	
	//getters
	public Text getWord() {
		return this.word;
	}
	
	public Text getDocID() {
		return this.docID;
	}

	
	//methode pour convertir en texte
	public Text toText() {
		return new Text(word.toString()+";"+docID.toString());
		
	}


	
}
	