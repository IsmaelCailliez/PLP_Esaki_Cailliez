package cs.bigdata.Tutorial2;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;


public class  DocWcWpdWritable implements WritableComparable <DocWcWpdWritable>{

	
	// declaration des attributs
	private Text docID; //nom du document
	private IntWritable wordCount; //nombre d'occurrences d'un mot dans ce document
	private IntWritable wordsPerDoc; //nombre de mots total dans le document
	
	
	//1er constructeur sans arguments
	public DocWcWpdWritable() {
		this.docID=new Text();
		this.wordsPerDoc=new IntWritable();
		this.wordCount=new IntWritable();
	}

	
	//2e constructeur avec arguments
	public DocWcWpdWritable(Text docID,IntWritable wordCount,IntWritable wordsPerDoc) {
		this.docID=docID;
		this.wordsPerDoc=wordsPerDoc;
		this.wordCount=wordCount;

	}




	@Override
	public void readFields(DataInput input) throws IOException {
		docID.readFields(input);
		wordsPerDoc.readFields(input);
		wordCount.readFields(input);
		
	}



	@Override
	public void write(DataOutput output) throws IOException {
		docID.write(output);
		wordsPerDoc.write(output);
		wordCount.write(output);
	}



	@Override
	public int compareTo(DocWcWpdWritable o) {
		return 0;

	}
	
	
	//setter
	public void set(String doc,int wordCount, int wordsPerDoc) {
		// TODO Auto-generated method stub
		this.docID=new Text(doc);
		this.wordCount=new IntWritable(wordCount);
		this.wordsPerDoc=new IntWritable(wordsPerDoc);
	}

	//getters
	public Text getDocID() {
		return docID;
	}
	
	public IntWritable getWordCount() {
		return this.wordCount;
	}
	
	public IntWritable getWordsPerDoc() {
		return this.wordsPerDoc;
	}




	
}
	